<?php
/**
 * Plugin Name: Webzlo COD Checkout Ecosystem
 * Description: Elementor-supported WooCommerce one-page COD checkout with incomplete-order CRM, fraud checks, blacklist, phone reputation and recovery tools.
 * Version: 2.6.0
 * Author: Webzlo
 * Text Domain: webzlo-one-page-checkout
 * Requires Plugins: woocommerce, elementor
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'WZL_OPC_VERSION' ) ) define( 'WZL_OPC_VERSION', '2.6.0' );
if ( ! defined( 'WZL_OPC_FILE' ) ) define( 'WZL_OPC_FILE', __FILE__ );
if ( ! defined( 'WZL_OPC_PATH' ) ) define( 'WZL_OPC_PATH', plugin_dir_path( __FILE__ ) );
if ( ! defined( 'WZL_OPC_URL' ) ) define( 'WZL_OPC_URL', plugin_dir_url( __FILE__ ) );

require_once WZL_OPC_PATH . 'includes/class-wzl-opc-activator.php';
require_once WZL_OPC_PATH . 'includes/class-wzl-opc-settings.php';
require_once WZL_OPC_PATH . 'includes/class-wzl-opc-security.php';
require_once WZL_OPC_PATH . 'includes/class-wzl-opc-reputation.php';
require_once WZL_OPC_PATH . 'includes/class-wzl-opc-ajax.php';
require_once WZL_OPC_PATH . 'includes/class-wzl-opc-admin.php';
require_once WZL_OPC_PATH . 'includes/class-wzl-opc-cron.php';
require_once WZL_OPC_PATH . 'includes/class-wzl-opc-steadfast.php';

register_activation_hook( __FILE__, array( 'WZL_OPC_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'WZL_OPC_Cron', 'deactivate' ) );

if ( ! class_exists( 'WZL_One_Page_Checkout' ) ) {
final class WZL_One_Page_Checkout {
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function init() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( $this, 'woocommerce_notice' ) );
			return;
		}

		WZL_OPC_Activator::maybe_upgrade();
		new WZL_OPC_Ajax();
		new WZL_OPC_Admin();
		new WZL_OPC_Cron();
		new WZL_OPC_Steadfast();

		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widget' ) );
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_category' ) );
	}

	public function register_assets() {
		wp_register_style( 'wzl-opc', WZL_OPC_URL . 'assets/css/checkout.css', array(), WZL_OPC_VERSION );
		wp_register_script( 'wzl-opc', WZL_OPC_URL . 'assets/js/checkout.js', array( 'jquery' ), WZL_OPC_VERSION, true );

		wp_localize_script(
			'wzl-opc',
			'WZLOPC',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wzl_opc_nonce' ),
				'i18n'    => array(
					'required' => __( 'Please complete all required fields.', 'webzlo-one-page-checkout' ),
					'phone'    => __( 'Please enter a valid Bangladeshi mobile number.', 'webzlo-one-page-checkout' ),
					'error'    => __( 'Something went wrong. Please try again.', 'webzlo-one-page-checkout' ),
					'success'  => __( 'Order placed successfully.', 'webzlo-one-page-checkout' ),
				),
			)
		);
	}

	public function register_category( $elements_manager ) {
		$elements_manager->add_category(
			'webzlo-elements',
			array(
				'title' => __( 'Webzlo Elements', 'webzlo-one-page-checkout' ),
				'icon'  => 'fa fa-plug',
			)
		);
	}

	public function register_widget( $widgets_manager ) {
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}
		require_once WZL_OPC_PATH . 'includes/class-wzl-opc-widget.php';
		$widgets_manager->register( new WZL_OPC_Widget() );
	}

	public function woocommerce_notice() {
		echo '<div class="notice notice-error"><p>' .
			esc_html__( 'Webzlo COD Checkout Ecosystem requires WooCommerce.', 'webzlo-one-page-checkout' ) .
		'</p></div>';
	}
}

}
WZL_One_Page_Checkout::instance();
