document.addEventListener('DOMContentLoaded', function () {
	'use strict';

	const modal = document.getElementById('wzl-opc-details-modal');
	if (!modal) {
		return;
	}

	const dialog = modal.querySelector('.wzl-opc-modal-dialog');
	let lastTrigger = null;

	function setText(field, value) {
		const element = modal.querySelector('[data-field="' + field + '"]');
		if (element) {
			element.textContent = value || '—';
		}
	}

	function openModal(details, trigger) {
		lastTrigger = trigger;

		[
			'customer_name',
			'phone',
			'thikana',
			'upazila_city',
			'zilla',
			'full_address',
			'product_name',
			'quantity',
			'subtotal',
			'shipping',
			'total',
			'fraud_score',
			'fraud_reasons',
			'status',
			'created_at',
			'updated_at'
		].forEach(function (field) {
			setText(field, details[field]);
		});

		const phoneLink = modal.querySelector('[data-field-phone]');
		if (phoneLink) {
			phoneLink.href = details.phone && details.phone !== '—' ? 'tel:' + details.phone : '#';
		}

		const image = modal.querySelector('[data-field-image]');
		const placeholder = modal.querySelector('[data-field-image-placeholder]');

		if (details.product_image) {
			image.src = details.product_image;
			image.alt = details.product_name || 'Product';
			image.hidden = false;
			placeholder.hidden = true;
		} else {
			image.removeAttribute('src');
			image.hidden = true;
			placeholder.hidden = false;
		}

		const sourceLink = modal.querySelector('[data-field-source]');
		if (details.source_url) {
			sourceLink.href = details.source_url;
			sourceLink.hidden = false;
		} else {
			sourceLink.hidden = true;
			sourceLink.removeAttribute('href');
		}

		const orderLink = modal.querySelector('[data-field-order]');
		if (details.wc_order_url) {
			orderLink.href = details.wc_order_url;
			orderLink.textContent = 'Open WooCommerce Order #' + details.wc_order_id;
			orderLink.hidden = false;
		} else {
			orderLink.hidden = true;
			orderLink.removeAttribute('href');
		}

		modal.hidden = false;
		document.body.classList.add('wzl-opc-modal-open');

		window.requestAnimationFrame(function () {
			modal.classList.add('is-open');
			const closeButton = modal.querySelector('.wzl-opc-modal-close');
			if (closeButton) {
				closeButton.focus();
			}
		});
	}

	function closeModal() {
		modal.classList.remove('is-open');
		document.body.classList.remove('wzl-opc-modal-open');

		window.setTimeout(function () {
			modal.hidden = true;
			if (lastTrigger) {
				lastTrigger.focus();
			}
		}, 180);
	}

	document.addEventListener('click', function (event) {
		const trigger = event.target.closest('.wzl-opc-view-order, .wzl-opc-view-customer');

		if (trigger) {
			event.preventDefault();

			try {
				const details = JSON.parse(trigger.getAttribute('data-details') || '{}');
				openModal(details, trigger);
			} catch (error) {
				window.alert('Unable to open this incomplete order.');
			}
			return;
		}

		if (event.target.closest('[data-wzl-close-modal]')) {
			event.preventDefault();
			closeModal();
		}
	});

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape' && !modal.hidden) {
			closeModal();
		}

		if (event.key === 'Tab' && !modal.hidden) {
			const focusable = dialog.querySelectorAll(
				'a[href]:not([hidden]), button:not([disabled]), [tabindex]:not([tabindex="-1"])'
			);

			if (!focusable.length) {
				return;
			}

			const first = focusable[0];
			const last = focusable[focusable.length - 1];

			if (event.shiftKey && document.activeElement === first) {
				event.preventDefault();
				last.focus();
			} else if (!event.shiftKey && document.activeElement === last) {
				event.preventDefault();
				first.focus();
			}
		}
	});
});
