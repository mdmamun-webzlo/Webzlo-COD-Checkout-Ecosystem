(function ($) {
	'use strict';

	function formatMoney(value) {
		try {
			return new Intl.NumberFormat(document.documentElement.lang || 'en-US', {
				style: 'currency',
				currency: 'BDT',
				maximumFractionDigits: 2
			}).format(value);
		} catch (e) {
			return '৳' + Number(value).toFixed(2);
		}
	}

	function validPhone(phone) {
		phone = String(phone || '').replace(/[^\d+]/g, '');

		if (phone.indexOf('+880') === 0) {
			phone = '0' + phone.substring(4);
		} else if (phone.indexOf('880') === 0) {
			phone = '0' + phone.substring(3);
		}

		return /^01[3-9][0-9]{8}$/.test(phone);
	}

	function initCheckout($wrap) {
		if ($wrap.data('initialized')) return;
		$wrap.data('initialized', true);

		const $form = $wrap.find('.wzl-opc-form');
		const price = parseFloat($wrap.attr('data-price')) || 0;
		const shipping = parseFloat($wrap.attr('data-shipping')) || 0;
		const maxQuantity = Math.max(1, parseInt($wrap.attr('data-max-quantity'), 10) || 20);
		let saveTimer = null;
		let placingOrder = false;

		function quantity() {
			return Math.min(maxQuantity, Math.max(1, parseInt($form.find('[name="quantity"]').val(), 10) || 1));
		}

		function updateTotals() {
			const subtotal = price * quantity();
			$form.find('.wzl-opc-subtotal').text(formatMoney(subtotal));
			$form.find('.wzl-opc-shipping').text(formatMoney(shipping));
			$form.find('.wzl-opc-total').text(formatMoney(subtotal + shipping));
		}

		function payload(action) {
			return {
				action: action,
				nonce: WZLOPC.nonce,
				session_key: $form.find('[name="session_key"]').val(),
				quantity: quantity(),
				customer_name: $form.find('[name="customer_name"]').val(),
				phone: $form.find('[name="phone"]').val(),
				thikana: $form.find('[name="thikana"]').val(),
				upazila_city: $form.find('[name="upazila_city"]').val(),
				district: $form.find('[name="district"]').val(),
				checkout_token: $form.find('[name="checkout_token"]').val(),
				website: $form.find('[name="website"]').val(),
				landing_url: window.location.href,
				referrer_url: document.referrer
			};
		}

		function saveIncomplete() {
			const phone = $form.find('[name="phone"]').val();

			if (!validPhone(phone) || placingOrder) return;

			$.post(WZLOPC.ajaxUrl, payload('wzl_opc_save_incomplete'));
		}

		function scheduleSave() {
			clearTimeout(saveTimer);
			saveTimer = setTimeout(saveIncomplete, 900);
		}

		$form.on('click', '.wzl-opc-minus, .wzl-opc-plus', function () {
			const $input = $form.find('[name="quantity"]');
			let value = quantity();

			if ($(this).hasClass('wzl-opc-plus')) value++;
			else value = Math.max(1, value - 1);

			$input.val(value).trigger('change');
		});

		$form.on('input change', 'input, textarea', function () {
			updateTotals();
			scheduleSave();
		});

		$form.on('submit', function (event) {
			event.preventDefault();

			const name = $.trim($form.find('[name="customer_name"]').val());
			const phone = $.trim($form.find('[name="phone"]').val());
			const thikana = $.trim($form.find('[name="thikana"]').val());
			const upazilaCity = $.trim($form.find('[name="upazila_city"]').val());
			const district = $.trim($form.find('[name="district"]').val());
			const $message = $form.find('.wzl-opc-message');
			const $button = $form.find('.wzl-opc-submit');

			$message.removeClass('is-error is-success').empty();

			if (!name || !thikana || !upazilaCity || !district) {
				$message.addClass('is-error').text(WZLOPC.i18n.required);
				return;
			}

			if (!validPhone(phone)) {
				$message.addClass('is-error').text(WZLOPC.i18n.phone);
				return;
			}

			placingOrder = true;
			$button.prop('disabled', true).addClass('is-loading');

			$.post(WZLOPC.ajaxUrl, payload('wzl_opc_place_order'))
				.done(function (response) {
					if (response && response.success && response.data.redirect) {
						$message.addClass('is-success').text(WZLOPC.i18n.success);
						window.location.href = response.data.redirect;
						return;
					}

					const error = response && response.data && response.data.message
						? response.data.message
						: WZLOPC.i18n.error;

					$message.addClass('is-error').text(error);
				})
				.fail(function () {
					$message.addClass('is-error').text(WZLOPC.i18n.error);
				})
				.always(function () {
					placingOrder = false;
					$button.prop('disabled', false).removeClass('is-loading');
				});
		});

		updateTotals();
	}

	function boot() {
		$('.wzl-opc-wrap').each(function () {
			initCheckout($(this));
		});
	}

	$(document).ready(boot);
	$(window).on('elementor/frontend/init', function () {
		if (window.elementorFrontend && elementorFrontend.hooks) {
			elementorFrontend.hooks.addAction(
				'frontend/element_ready/wzl-one-page-checkout.default',
				function ($scope) {
					$scope.find('.wzl-opc-wrap').each(function () {
						initCheckout($(this));
					});
				}
			);
		}
	});
})(jQuery);
