<?php
defined( 'ABSPATH' ) || exit;

class WZL_OPC_Activator {
	const DB_VERSION = '2.5.0';

	public static function default_settings() {
		return array(
			'duplicate_window'        => 10,
			'max_orders_hour'         => 5,
			'max_incomplete_hour'     => 20,
			'max_quantity'            => 20,
			'max_orders_phone_day'    => 3,
			'abandoned_minutes'       => 30,
			'address_min_length'      => 10,
			'high_risk_threshold'     => 60,
			'block_risk_threshold'    => 80,
			'data_retention_days'     => 180,
			'blacklist_action'        => 'block',
			'enable_honeypot'         => 'yes',
			'enable_rate_limit'       => 'yes',
			'enable_phone_reputation' => 'yes',
			'whatsapp_template'       => 'Hello {name}, you started an order for {product}. Would you like help completing it?',
		);
	}

	public static function activate() {
		self::install_tables();
		update_option( 'wzl_opc_settings', wp_parse_args( get_option( 'wzl_opc_settings', array() ), self::default_settings() ) );
		update_option( 'wzl_opc_db_version', self::DB_VERSION );
		WZL_OPC_Cron::schedule();
	}

	public static function maybe_upgrade() {
		if ( get_option( 'wzl_opc_db_version' ) !== self::DB_VERSION ) {
			self::activate();
		}
	}

	private static function install_tables() {
		global $wpdb;
		$c = $wpdb->get_charset_collate();
		$sql = array();
		$sql[] = "CREATE TABLE {$wpdb->prefix}wzl_incomplete_orders (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			session_key varchar(100) NOT NULL,
			product_id bigint(20) unsigned NOT NULL DEFAULT 0,
			variation_id bigint(20) unsigned NOT NULL DEFAULT 0,
			quantity int(11) unsigned NOT NULL DEFAULT 1,
			customer_name varchar(190) NOT NULL DEFAULT '',
			phone varchar(50) NOT NULL DEFAULT '',
			address text NOT NULL,
			thikana text NOT NULL,
			upazila_city varchar(190) NOT NULL DEFAULT '',
			district varchar(100) NOT NULL DEFAULT '',
			subtotal decimal(18,2) NOT NULL DEFAULT 0.00,
			shipping_total decimal(18,2) NOT NULL DEFAULT 0.00,
			order_total decimal(18,2) NOT NULL DEFAULT 0.00,
			status varchar(30) NOT NULL DEFAULT 'active',
			fraud_score int(11) NOT NULL DEFAULT 0,
			fraud_reasons text NOT NULL,
			fingerprint varchar(100) NOT NULL DEFAULT '',
			landing_url text NOT NULL,
			referrer_url text NOT NULL,
			admin_note text NOT NULL,
			wc_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY session_key (session_key), KEY phone (phone), KEY status (status)
		) {$c};";
		$sql[] = "CREATE TABLE {$wpdb->prefix}wzl_opc_phone_profiles (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			phone varchar(50) NOT NULL,
			total_orders int(11) unsigned NOT NULL DEFAULT 0,
			successful_orders int(11) unsigned NOT NULL DEFAULT 0,
			cancelled_orders int(11) unsigned NOT NULL DEFAULT 0,
			failed_orders int(11) unsigned NOT NULL DEFAULT 0,
			incomplete_checkouts int(11) unsigned NOT NULL DEFAULT 0,
			total_spent decimal(18,2) NOT NULL DEFAULT 0.00,
			trust_status varchar(30) NOT NULL DEFAULT 'new',
			last_order_at datetime NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY phone (phone)
		) {$c};";
		$sql[] = "CREATE TABLE {$wpdb->prefix}wzl_opc_blacklist (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			type varchar(30) NOT NULL DEFAULT 'phone',
			value varchar(190) NOT NULL,
			reason text NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY type_value (type,value)
		) {$c};";
		$sql[] = "CREATE TABLE {$wpdb->prefix}wzl_opc_fraud_events (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			session_key varchar(100) NOT NULL DEFAULT '', phone varchar(50) NOT NULL DEFAULT '',
			event_type varchar(50) NOT NULL, risk_score int(11) NOT NULL DEFAULT 0,
			details text NOT NULL, created_at datetime NOT NULL,
			PRIMARY KEY (id), KEY phone (phone), KEY event_type (event_type)
		) {$c};";
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		foreach ( $sql as $query ) dbDelta( $query );
	}
}
