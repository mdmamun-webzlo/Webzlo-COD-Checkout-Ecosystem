<?php
defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WZL_OPC_Steadfast' ) ) {
class WZL_OPC_Steadfast {
	const BASE_URL = 'https://portal.packzy.com/api/v1';

	public function __construct( $register_hooks = true ) {
		if ( ! $register_hooks ) return;
		add_action( 'woocommerce_order_status_processing', array( $this, 'maybe_auto_send' ), 20 );
		add_action( 'woocommerce_order_status_on-hold', array( $this, 'maybe_auto_send' ), 20 );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'admin_post_wzl_steadfast_send', array( $this, 'manual_send' ) );
		add_action( 'admin_post_wzl_steadfast_status', array( $this, 'manual_status' ) );
		add_action( 'admin_post_wzl_steadfast_return', array( $this, 'manual_return' ) );
		add_action( 'admin_notices', array( $this, 'admin_notice' ) );
	}

	public static function settings() {
		return wp_parse_args( get_option( 'wzl_opc_steadfast', array() ), array(
			'enabled' => 'no', 'api_key' => '', 'secret_key' => '', 'auto_send' => 'no',
			'auto_status' => 'processing', 'note_template' => 'Order #{order_number}: {products}',
		) );
	}

	private static function tabs( $active ) {
		$tabs = array( 'settings'=>'Settings', 'tools'=>'API Tools', 'returns'=>'Returns', 'payments'=>'Payments', 'police'=>'Police Stations' );
		echo '<nav class="nav-tab-wrapper">';
		foreach ( $tabs as $key=>$label ) {
			$url=add_query_arg(array('page'=>'wzl-steadfast','tab'=>$key),admin_url('admin.php'));
			echo '<a class="nav-tab '.esc_attr($active===$key?'nav-tab-active':'').'" href="'.esc_url($url).'">'.esc_html($label).'</a>';
		}
		echo '</nav>';
	}

	public static function settings_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) wp_die( esc_html__( 'You do not have permission to access this page.', 'webzlo-one-page-checkout' ) );
		$api = new self( false );
		$tab = sanitize_key( $_GET['tab'] ?? 'settings' );
		$allowed=array('settings','tools','returns','payments','police'); if(!in_array($tab,$allowed,true))$tab='settings';
		$notice=''; $error=''; $result_data=null;

		if ( isset( $_POST['wzl_save_steadfast'] ) ) {
			check_admin_referer( 'wzl_save_steadfast_settings' );
			$current=self::settings();
			$api_key=sanitize_text_field(wp_unslash($_POST['api_key']??''));
			$secret=sanitize_text_field(wp_unslash($_POST['secret_key']??''));
			if('********'===$api_key)$api_key=$current['api_key']; if('********'===$secret)$secret=$current['secret_key'];
			update_option('wzl_opc_steadfast',array(
				'enabled'=>isset($_POST['enabled'])?'yes':'no','api_key'=>$api_key,'secret_key'=>$secret,
				'auto_send'=>isset($_POST['auto_send'])?'yes':'no',
				'auto_status'=>in_array(sanitize_key($_POST['auto_status']??'processing'),array('processing','on-hold'),true)?sanitize_key($_POST['auto_status']):'processing',
				'note_template'=>sanitize_textarea_field(wp_unslash($_POST['note_template']??'')),
			),false);
			$notice='Steadfast settings saved.';
		}

		if ( isset( $_POST['wzl_sf_tool_action'] ) ) {
			check_admin_referer('wzl_sf_tools');
			$action=sanitize_key($_POST['wzl_sf_tool_action']);
			if('balance'===$action){$result_data=$api->get_balance();}
			elseif('bulk'===$action){
				$ids=array_values(array_filter(array_map('absint',preg_split('/[\s,]+/',sanitize_text_field(wp_unslash($_POST['order_ids']??''))))));
				$result_data=$api->bulk_create($ids);
			}
			if(is_wp_error($result_data)){$error=$result_data->get_error_message();$result_data=null;}
			else{$notice='Steadfast API request completed.';}
		}

		if ( isset( $_POST['wzl_sf_return_action'] ) ) {
			check_admin_referer('wzl_sf_returns');
			$action=sanitize_key($_POST['wzl_sf_return_action']);
			if('create'===$action){
				$identifier=sanitize_text_field(wp_unslash($_POST['identifier']??''));
				$reason=sanitize_textarea_field(wp_unslash($_POST['reason']??''));
				$result_data=$api->create_return_request($identifier,$reason);
			}else{$result_data=$api->get_return_requests();}
			if(is_wp_error($result_data)){$error=$result_data->get_error_message();$result_data=null;}else{$notice='Return API request completed.';}
		}

		if ( 'payments'===$tab && isset($_GET['load']) ) {
			$payment_id=absint($_GET['payment_id']??0); $result_data=$payment_id?$api->get_payment($payment_id):$api->get_payments();
			if(is_wp_error($result_data)){$error=$result_data->get_error_message();$result_data=null;}
		}
		if ( 'police'===$tab && isset($_GET['load']) ) {
			$result_data=$api->get_police_stations(); if(is_wp_error($result_data)){$error=$result_data->get_error_message();$result_data=null;}
		}

		$settings=self::settings();
		echo '<div class="wrap"><h1>Steadfast Courier</h1>'; self::tabs($tab);
		if($notice)echo '<div class="notice notice-success"><p>'.esc_html($notice).'</p></div>';
		if($error)echo '<div class="notice notice-error"><p>'.esc_html($error).'</p></div>';
		if('settings'===$tab) self::render_settings($settings);
		elseif('tools'===$tab) self::render_tools($result_data);
		elseif('returns'===$tab) self::render_returns($result_data);
		elseif('payments'===$tab) self::render_payments($result_data);
		else self::render_police($result_data);
		echo '</div>';
	}

	private static function render_settings($s){
		$api=$s['api_key']?'********':'';$secret=$s['secret_key']?'********':'';
		echo '<p><strong>API Base URL:</strong> <code>'.esc_html(self::BASE_URL).'</code></p><form method="post">'; wp_nonce_field('wzl_save_steadfast_settings');
		echo '<table class="form-table"><tr><th>Enable integration</th><td><label><input type="checkbox" name="enabled" '.checked($s['enabled'],'yes',false).'> Enable Steadfast API</label></td></tr>';
		echo '<tr><th>API Key</th><td><input class="regular-text" type="password" name="api_key" value="'.esc_attr($api).'" autocomplete="new-password"></td></tr>';
		echo '<tr><th>Secret Key</th><td><input class="regular-text" type="password" name="secret_key" value="'.esc_attr($secret).'" autocomplete="new-password"></td></tr>';
		echo '<tr><th>Automatic submission</th><td><label><input type="checkbox" name="auto_send" '.checked($s['auto_send'],'yes',false).'> Automatically send orders</label></td></tr>';
		echo '<tr><th>Send status</th><td><select name="auto_status"><option value="processing" '.selected($s['auto_status'],'processing',false).'>Processing</option><option value="on-hold" '.selected($s['auto_status'],'on-hold',false).'>On hold</option></select></td></tr>';
		echo '<tr><th>Courier note</th><td><textarea class="large-text" rows="4" name="note_template">'.esc_textarea($s['note_template']).'</textarea><p>{order_number}, {products}</p></td></tr></table>';
		submit_button('Save Steadfast Settings','primary','wzl_save_steadfast'); echo '</form>';
	}
	private static function render_tools($data){
		echo '<h2>Current Balance</h2><form method="post">';wp_nonce_field('wzl_sf_tools');echo '<button class="button button-primary" name="wzl_sf_tool_action" value="balance">Check Balance</button></form>';
		echo '<h2>Bulk Order Create</h2><p>Enter up to 500 WooCommerce order IDs, separated by commas or spaces. Already submitted orders are skipped.</p><form method="post">';wp_nonce_field('wzl_sf_tools');echo '<textarea class="large-text" rows="5" name="order_ids" placeholder="123, 124, 125"></textarea><p><button class="button button-primary" name="wzl_sf_tool_action" value="bulk">Create Bulk Parcels</button></p></form>';
		self::render_json($data);
	}
	private static function render_returns($data){
		echo '<h2>Create Return Request</h2><form method="post">';wp_nonce_field('wzl_sf_returns');echo '<table class="form-table"><tr><th>Consignment ID, Invoice or Tracking Code</th><td><input class="regular-text" name="identifier" required></td></tr><tr><th>Reason</th><td><textarea class="large-text" name="reason"></textarea></td></tr></table><button class="button button-primary" name="wzl_sf_return_action" value="create">Create Return Request</button> <button class="button" name="wzl_sf_return_action" value="list">Load Return Requests</button></form>';
		self::render_json($data);
	}
	private static function render_payments($data){
		$base=add_query_arg(array('page'=>'wzl-steadfast','tab'=>'payments','load'=>1),admin_url('admin.php'));
		echo '<p><a class="button button-primary" href="'.esc_url($base).'">Load Payments</a></p><form method="get"><input type="hidden" name="page" value="wzl-steadfast"><input type="hidden" name="tab" value="payments"><input type="hidden" name="load" value="1"><input type="number" min="1" name="payment_id" placeholder="Payment ID"> <button class="button">Load Single Payment</button></form>';
		self::render_json($data);
	}
	private static function render_police($data){
		$url=add_query_arg(array('page'=>'wzl-steadfast','tab'=>'police','load'=>1),admin_url('admin.php'));
		echo '<p><a class="button button-primary" href="'.esc_url($url).'">Load Police Stations</a></p>';self::render_json($data);
	}
	private static function render_json($data){if(null===$data)return;echo '<h2>API Response</h2><pre style="max-height:600px;overflow:auto;background:#fff;border:1px solid #ccd0d4;padding:15px;white-space:pre-wrap">'.esc_html(wp_json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</pre>';}

	private function headers(){ $s=self::settings(); return array('Api-Key'=>trim($s['api_key']),'Secret-Key'=>trim($s['secret_key']),'Content-Type'=>'application/json','Accept'=>'application/json'); }
	private function request($method,$path,$body=null){
		$s=self::settings(); if('yes'!==$s['enabled']||empty($s['api_key'])||empty($s['secret_key']))return new WP_Error('steadfast_config','Steadfast API is not configured or enabled.');
		$args=array('method'=>$method,'timeout'=>45,'redirection'=>2,'headers'=>$this->headers(),'sslverify'=>true);
		if(null!==$body)$args['body']=wp_json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
		$url=trailingslashit(self::BASE_URL).ltrim($path,'/');$response=wp_remote_request($url,$args);
		if(is_wp_error($response))return new WP_Error('steadfast_transport','Steadfast connection error: '.$response->get_error_message());
		$code=(int)wp_remote_retrieve_response_code($response);$raw=trim((string)wp_remote_retrieve_body($response));$data=json_decode($raw,true);if(JSON_ERROR_NONE!==json_last_error())$data=null;
		if($code<200||$code>=300){$msg='';if(is_array($data)){$msg=is_scalar($data['message']??null)?sanitize_text_field((string)$data['message']):'';if(!$msg&&is_scalar($data['error']??null))$msg=sanitize_text_field((string)$data['error']);}if(!$msg)$msg=sanitize_text_field(wp_strip_all_tags(substr($raw,0,600)))?:'No response details returned.';return new WP_Error('steadfast_http',sprintf('Steadfast API error (HTTP %d): %s',$code,$msg),array('response'=>$data));}
		if(!is_array($data))return new WP_Error('steadfast_json','Steadfast returned an unreadable response.');
		if(isset($data['status'])&&is_numeric($data['status'])&&(int)$data['status']>=400)return new WP_Error('steadfast_api','Steadfast API error: '.sanitize_text_field((string)($data['message']??'Unknown error.')));
		return $data;
	}
	private function product_summary(WC_Order $order){$p=array();foreach($order->get_items() as $i)$p[]=$i->get_name().' x '.$i->get_quantity();return implode(', ',$p);}
	private function normalize_phone($p){$p=preg_replace('/[^0-9]/','',(string)$p);if(0===strpos($p,'00880'))$p=substr($p,5);elseif(0===strpos($p,'880'))$p=substr($p,3);if(10===strlen($p)&&'1'===substr($p,0,1))$p='0'.$p;return $p;}
	private function payload(WC_Order $order){
		$s=self::settings();$address=array_filter(array($order->get_shipping_address_1()?:$order->get_billing_address_1(),$order->get_shipping_address_2()?:$order->get_billing_address_2(),$order->get_shipping_city()?:$order->get_billing_city(),$order->get_shipping_state()?:$order->get_billing_state()));$products=$this->product_summary($order);$note=strtr($s['note_template'],array('{order_number}'=>$order->get_order_number(),'{products}'=>$products));$name=trim($order->get_formatted_billing_full_name());
		return array('invoice'=>substr(preg_replace('/[^A-Za-z0-9_-]/','-',(string)$order->get_order_number()),0,100),'recipient_name'=>substr(wp_strip_all_tags($name),0,100),'recipient_phone'=>$this->normalize_phone($order->get_billing_phone()),'recipient_address'=>substr(implode(', ',$address),0,250),'cod_amount'=>round((float)$order->get_total(),2),'note'=>substr(wp_strip_all_tags($note),0,500),'item_description'=>substr(wp_strip_all_tags($products),0,500),'total_lot'=>max(1,(int)$order->get_item_count()),'delivery_type'=>0);
	}
	private function validate_payload($p){$e=array();if(empty($p['invoice']))$e[]='Invoice is missing.';if(empty($p['recipient_name']))$e[]='Customer name is missing.';if(!preg_match('/^01[3-9][0-9]{8}$/',$p['recipient_phone']))$e[]='Invalid Bangladesh phone number.';if(strlen(trim($p['recipient_address']))<5)$e[]='Address is missing or too short.';if((float)$p['cod_amount']<0)$e[]='COD amount cannot be negative.';return $e;}

	public function create_consignment($order_id){$o=wc_get_order($order_id);if(!$o)return new WP_Error('invalid_order','Order not found.');if($o->get_meta('_wzl_steadfast_consignment_id'))return new WP_Error('already_sent','This order has already been sent to Steadfast.');$p=$this->payload($o);$e=$this->validate_payload($p);if($e)return new WP_Error('validation',implode(' ',$e));$r=$this->request('POST','/create_order',$p);if(is_wp_error($r)){$o->update_meta_data('_wzl_steadfast_last_error',$r->get_error_message());$o->save();return $r;}$c=is_array($r['consignment']??null)?$r['consignment']:array();if(empty($c['consignment_id']))return new WP_Error('invalid_response',$r['message']??'No consignment ID returned.');$o->update_meta_data('_wzl_steadfast_consignment_id',absint($c['consignment_id']));$o->update_meta_data('_wzl_steadfast_tracking_code',sanitize_text_field($c['tracking_code']??''));$o->update_meta_data('_wzl_steadfast_status',sanitize_key($c['status']??'in_review'));$o->delete_meta_data('_wzl_steadfast_last_error');$o->add_order_note('Sent to Steadfast. Consignment ID: '.$c['consignment_id']);$o->save();return $r;}
	public function bulk_create($ids){if(!$ids)return new WP_Error('empty','Enter at least one WooCommerce order ID.');$ids=array_slice(array_unique(array_map('absint',$ids)),0,500);$data=array();foreach($ids as $id){$o=wc_get_order($id);if(!$o||$o->get_meta('_wzl_steadfast_consignment_id'))continue;$p=$this->payload($o);if(!$this->validate_payload($p))$data[]=$p;}if(!$data)return new WP_Error('none','No eligible orders found.');$r=$this->request('POST','/create_order/bulk-order',array('data'=>wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)));if(is_wp_error($r))return $r;foreach($r as $item){if(!is_array($item)||'success'!==($item['status']??''))continue;$invoice=(string)($item['invoice']??'');foreach($ids as $id){$o=wc_get_order($id);if($o&&(string)$o->get_order_number()===$invoice){$o->update_meta_data('_wzl_steadfast_consignment_id',absint($item['consignment_id']??0));$o->update_meta_data('_wzl_steadfast_tracking_code',sanitize_text_field($item['tracking_code']??''));$o->update_meta_data('_wzl_steadfast_status','in_review');$o->save();break;}}}return $r;}
	public function check_status($order_id){$o=wc_get_order($order_id);if(!$o)return new WP_Error('invalid_order','Order not found.');$cid=absint($o->get_meta('_wzl_steadfast_consignment_id'));if(!$cid)return new WP_Error('not_sent','Order has not been sent.');$r=$this->request('GET','/status_by_cid/'.rawurlencode((string)$cid));if(!is_wp_error($r)){$o->update_meta_data('_wzl_steadfast_status',sanitize_key($r['delivery_status']??'unknown'));$o->save();}return $r;}
	public function get_balance(){return $this->request('GET','/get_balance');}
	public function create_return_request($identifier,$reason=''){if(!$identifier)return new WP_Error('missing','Enter a consignment ID, invoice or tracking code.');$body=array('consignment_id'=>$identifier);if($reason)$body['reason']=$reason;return $this->request('POST','/create_return_request',$body);}
	public function get_return_requests(){return $this->request('GET','/get_return_requests');}
	public function get_return_request($id){return $this->request('GET','/get_return_request/'.rawurlencode((string)$id));}
	public function get_payments(){return $this->request('GET','/payments');}
	public function get_payment($id){return $this->request('GET','/payments/'.rawurlencode((string)$id));}
	public function get_police_stations(){return $this->request('GET','/police_stations');}
	public function maybe_auto_send($id){$s=self::settings();$o=wc_get_order($id);if('yes'===$s['enabled']&&'yes'===$s['auto_send']&&$o&&$o->get_status()===$s['auto_status'])$this->create_consignment($id);}

	public function add_meta_box(){add_meta_box('wzl-steadfast','Steadfast Courier',array($this,'render_meta_box'),'shop_order','side','high');if(function_exists('wc_get_page_screen_id')){try{$screen=wc_get_page_screen_id('shop-order');if($screen&&'shop_order'!==$screen)add_meta_box('wzl-steadfast-hpos','Steadfast Courier',array($this,'render_meta_box'),$screen,'side','high');}catch(Throwable $e){}}}
	public function render_meta_box($post_or_order){$o=$post_or_order instanceof WC_Order?$post_or_order:wc_get_order($post_or_order->ID);if(!$o)return;$cid=$o->get_meta('_wzl_steadfast_consignment_id');$status=$o->get_meta('_wzl_steadfast_status');echo '<p><strong>Consignment:</strong> '.esc_html($cid?:'Not sent').'</p><p><strong>Tracking:</strong> '.esc_html($o->get_meta('_wzl_steadfast_tracking_code')?:'—').'</p><p><strong>Status:</strong> '.esc_html($status?:'—').'</p>';if($o->get_meta('_wzl_steadfast_last_error'))echo '<p style="color:#b32d2e">'.esc_html($o->get_meta('_wzl_steadfast_last_error')).'</p>';if(!$cid){$u=wp_nonce_url(admin_url('admin-post.php?action=wzl_steadfast_send&order_id='.$o->get_id()),'wzl_steadfast_send_'.$o->get_id());echo '<p><a class="button button-primary" href="'.esc_url($u).'">Send to Steadfast</a></p>';}else{$u=wp_nonce_url(admin_url('admin-post.php?action=wzl_steadfast_status&order_id='.$o->get_id()),'wzl_steadfast_status_'.$o->get_id());$r=wp_nonce_url(admin_url('admin-post.php?action=wzl_steadfast_return&order_id='.$o->get_id()),'wzl_steadfast_return_'.$o->get_id());echo '<p><a class="button" href="'.esc_url($u).'">Check Status</a> <a class="button" href="'.esc_url($r).'" onclick="return confirm(\'Create a Steadfast return request for this order?\')">Request Return</a></p>';}}
	public function manual_send(){$this->handle_admin_action('send');} public function manual_status(){$this->handle_admin_action('status');} public function manual_return(){$this->handle_admin_action('return');}
	private function handle_admin_action($type){if(!current_user_can('manage_woocommerce'))wp_die('Unauthorized.');$id=absint($_GET['order_id']??0);check_admin_referer('wzl_steadfast_'.$type.'_'.$id);if('send'===$type)$r=$this->create_consignment($id);elseif('status'===$type)$r=$this->check_status($id);else{$o=wc_get_order($id);$ident=$o?($o->get_meta('_wzl_steadfast_consignment_id')?:$o->get_order_number()):'';$r=$this->create_return_request($ident,'Return requested from WooCommerce order #'.$id);} $key=is_wp_error($r)?'wzl_sf_error':'wzl_sf_success';$msg=is_wp_error($r)?$r->get_error_message():ucfirst($type).' request completed.';wp_safe_redirect(add_query_arg($key,rawurlencode($msg),wp_get_referer()?:admin_url()));exit;}
	public function admin_notice(){if(!current_user_can('manage_woocommerce'))return;if(isset($_GET['wzl_sf_success']))echo '<div class="notice notice-success is-dismissible"><p>'.esc_html(rawurldecode(wp_unslash($_GET['wzl_sf_success']))).'</p></div>';if(isset($_GET['wzl_sf_error']))echo '<div class="notice notice-error is-dismissible"><p>'.esc_html(rawurldecode(wp_unslash($_GET['wzl_sf_error']))).'</p></div>';}
}
}
