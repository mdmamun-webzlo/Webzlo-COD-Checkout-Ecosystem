<?php
defined( 'ABSPATH' ) || exit;

class WZL_OPC_Ajax {
	public function __construct() {
		add_action( 'wp_ajax_wzl_opc_save_incomplete', array( $this, 'save_incomplete' ) );
		add_action( 'wp_ajax_nopriv_wzl_opc_save_incomplete', array( $this, 'save_incomplete' ) );
		add_action( 'wp_ajax_wzl_opc_place_order', array( $this, 'place_order' ) );
		add_action( 'wp_ajax_nopriv_wzl_opc_place_order', array( $this, 'place_order' ) );
	}

	private function verify() { check_ajax_referer( 'wzl_opc_nonce', 'nonce' ); }
	private function phone( $phone ) {
		$phone = preg_replace( '/[^0-9+]/', '', (string) $phone );
		if ( 0 === strpos( $phone, '+880' ) ) $phone = '0' . substr( $phone, 4 );
		elseif ( 0 === strpos( $phone, '880' ) ) $phone = '0' . substr( $phone, 3 );
		return $phone;
	}
	private function valid_phone( $phone ) { return (bool) preg_match( '/^01[3-9][0-9]{8}$/', $phone ); }
	private function fingerprint() {
		$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) );
		$ua = sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ?? '' ) );
		return hash_hmac( 'sha256', $ip . '|' . $ua, wp_salt( 'auth' ) );
	}
	private function limited( $bucket, $limit, $ttl ) {
		$key = 'wzl_opc_rl_' . hash( 'sha256', $bucket );
		$count = (int) get_transient( $key );
		if ( $count >= $limit ) return true;
		set_transient( $key, $count + 1, $ttl );
		return false;
	}
	private function checkout_context() {
		$token = sanitize_text_field( wp_unslash( $_POST['checkout_token'] ?? '' ) );
		$data  = WZL_OPC_Security::verify_checkout_token( $token );
		if ( is_wp_error( $data ) ) wp_send_json_error( array( 'message' => __( 'Checkout session expired. Please refresh the page.', 'webzlo-one-page-checkout' ) ) );
		$product = wc_get_product( $data['product_id'] );
		if ( ! $product || 'publish' !== get_post_status( $data['product_id'] ) || ! $product->is_type( 'simple' ) || ! $product->is_purchasable() ) {
			wp_send_json_error( array( 'message' => __( 'This product is unavailable.', 'webzlo-one-page-checkout' ) ) );
		}
		return array( $data, $product );
	}
	private function quantity( $product, $max ) {
		$qty = absint( $_POST['quantity'] ?? 1 );
		if ( $qty < 1 || $qty > $max || $product->is_sold_individually() && $qty > 1 ) wp_send_json_error( array( 'message' => __( 'Invalid product quantity.', 'webzlo-one-page-checkout' ) ) );
		if ( $product->managing_stock() && ! $product->has_enough_stock( $qty ) ) wp_send_json_error( array( 'message' => __( 'Requested quantity is not available.', 'webzlo-one-page-checkout' ) ) );
		return $qty;
	}

	private function valid_districts() {
		return array(
			'Bagerhat','Bandarban','Barguna','Barishal','Bhola','Bogura','Brahmanbaria','Chandpur',
			'Chapainawabganj','Chattogram','Chuadanga','Cox’s Bazar','Cumilla','Dhaka','Dinajpur','Faridpur',
			'Feni','Gaibandha','Gazipur','Gopalganj','Habiganj','Jamalpur','Jashore','Jhalokati','Jhenaidah',
			'Joypurhat','Khagrachhari','Khulna','Kishoreganj','Kurigram','Kushtia','Lakshmipur','Lalmonirhat',
			'Madaripur','Magura','Manikganj','Meherpur','Moulvibazar','Munshiganj','Mymensingh','Naogaon',
			'Narail','Narayanganj','Narsingdi','Natore','Netrokona','Nilphamari','Noakhali','Pabna','Panchagarh',
			'Patuakhali','Pirojpur','Rajbari','Rajshahi','Rangamati','Rangpur','Satkhira','Shariatpur','Sherpur',
			'Sirajganj','Sunamganj','Sylhet','Tangail','Thakurgaon'
		);
	}
	private function address_fields() {
		$thikana = mb_substr( sanitize_textarea_field( wp_unslash( $_POST['thikana'] ?? '' ) ), 0, 500 );
		$upazila_city = mb_substr( sanitize_text_field( wp_unslash( $_POST['upazila_city'] ?? '' ) ), 0, 100 );
		$district = mb_substr( sanitize_text_field( wp_unslash( $_POST['district'] ?? '' ) ), 0, 100 );
		if ( ! in_array( $district, $this->valid_districts(), true ) ) {
			$district = '';
		}
		$combined = implode( ', ', array_filter( array( $thikana, $upazila_city, $district ) ) );
		return array( $thikana, $upazila_city, $district, $combined );
	}

	private function risk( $phone, $name, $address, $fingerprint ) {
		$score = 0; $reasons = array();
		if ( mb_strlen( $name ) < 3 ) { $score += 20; $reasons[] = 'Short name'; }
		if ( mb_strlen( $address ) < max( 10, (int) WZL_OPC_Settings::get( 'address_min_length', 10 ) ) ) { $score += 30; $reasons[] = 'Short address'; }
		if ( preg_match( '/(.)\1{5,}/u', $name . ' ' . $address ) ) { $score += 35; $reasons[] = 'Repeated characters'; }
		if ( WZL_OPC_Reputation::is_blacklisted( $phone, $fingerprint ) ) { $score = 100; $reasons[] = 'Blacklisted'; }
		$count = count( wc_get_orders( array( 'limit' => 10, 'billing_phone' => $phone, 'date_created' => '>' . ( time() - DAY_IN_SECONDS ), 'return' => 'ids' ) ) );
		if ( $count >= max( 1, (int) WZL_OPC_Settings::get( 'max_orders_phone_day', 3 ) ) ) { $score += 40; $reasons[] = 'Daily phone limit'; }
		return array( 'score' => min( 100, $score ), 'reasons' => implode( ', ', $reasons ) );
	}
	private function duplicate( $phone, $product_id ) {
		$window = max( 1, (int) WZL_OPC_Settings::get( 'duplicate_window', 10 ) ) * MINUTE_IN_SECONDS;
		$orders = wc_get_orders( array( 'limit' => 20, 'status' => array( 'wc-pending','wc-processing','wc-on-hold','wc-completed' ), 'billing_phone' => $phone, 'date_created' => '>' . ( time() - $window ), 'return' => 'objects' ) );
		foreach ( $orders as $order ) foreach ( $order->get_items() as $item ) if ( (int) $item->get_product_id() === (int) $product_id ) return true;
		return false;
	}

	public function save_incomplete() {
		$this->verify();
		$session = sanitize_text_field( wp_unslash( $_POST['session_key'] ?? '' ) );
		if ( ! WZL_OPC_Security::valid_session_key( $session ) ) wp_send_json_error( array( 'message' => __( 'Invalid checkout session.', 'webzlo-one-page-checkout' ) ) );
		list( $ctx, $product ) = $this->checkout_context();
		$qty = $this->quantity( $product, $ctx['max_quantity'] );
		$name = mb_substr( sanitize_text_field( wp_unslash( $_POST['customer_name'] ?? '' ) ), 0, 100 );
		$phone = $this->phone( wp_unslash( $_POST['phone'] ?? '' ) );
		list( $thikana, $upazila_city, $district, $address ) = $this->address_fields();
		if ( ! $this->valid_phone( $phone ) ) wp_send_json_success( array( 'saved' => false ) );
		global $wpdb; $table = $wpdb->prefix . 'wzl_incomplete_orders';
		$id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE session_key=%s", $session ) );
		if ( ! $id && ( $this->limited( 'save-fp|' . $this->fingerprint(), max( 5, (int) WZL_OPC_Settings::get( 'max_incomplete_hour', 20 ) ), HOUR_IN_SECONDS ) || $this->limited( 'save-phone|' . $phone, 8, HOUR_IN_SECONDS ) ) ) {
			wp_send_json_error( array( 'message' => __( 'Too many checkout attempts. Please try again later.', 'webzlo-one-page-checkout' ) ) );
		}
		$subtotal = (float) wc_get_price_to_display( $product, array( 'qty' => $qty ) );
		$risk = $this->risk( $phone, $name, $address, $this->fingerprint() );
		$data = array( 'product_id'=>$ctx['product_id'], 'quantity'=>$qty, 'customer_name'=>$name, 'phone'=>$phone, 'address'=>$address, 'thikana'=>$thikana, 'upazila_city'=>$upazila_city, 'district'=>$district, 'subtotal'=>$subtotal, 'shipping_total'=>$ctx['shipping'], 'order_total'=>$subtotal+$ctx['shipping'], 'status'=>'active', 'fraud_score'=>$risk['score'], 'fraud_reasons'=>$risk['reasons'], 'fingerprint'=>$this->fingerprint(), 'landing_url'=>esc_url_raw( mb_substr( wp_unslash( $_POST['landing_url'] ?? '' ), 0, 2000 ) ), 'referrer_url'=>esc_url_raw( mb_substr( wp_unslash( $_POST['referrer_url'] ?? '' ), 0, 2000 ) ), 'updated_at'=>current_time('mysql') );
		if ( $id ) $wpdb->update( $table, $data, array( 'id'=>(int)$id ) ); else { $data['session_key']=$session; $data['created_at']=current_time('mysql'); $wpdb->insert( $table, $data ); }
		wp_send_json_success( array( 'saved'=>true ) );
	}

	public function place_order() {
		$this->verify();
		if ( 'yes' === WZL_OPC_Settings::get( 'enable_honeypot', 'yes' ) && ! empty( $_POST['website'] ) ) wp_send_json_error( array( 'message'=>__( 'Order verification failed.', 'webzlo-one-page-checkout' ) ) );
		$session = sanitize_text_field( wp_unslash( $_POST['session_key'] ?? '' ) );
		if ( ! WZL_OPC_Security::valid_session_key( $session ) ) wp_send_json_error( array( 'message'=>__( 'Invalid checkout session.', 'webzlo-one-page-checkout' ) ) );
		list( $ctx, $product ) = $this->checkout_context();
		$qty = $this->quantity( $product, $ctx['max_quantity'] );
		$name = mb_substr( sanitize_text_field( wp_unslash( $_POST['customer_name'] ?? '' ) ), 0, 100 );
		$phone = $this->phone( wp_unslash( $_POST['phone'] ?? '' ) );
		list( $thikana, $upazila_city, $district, $address ) = $this->address_fields();
		if ( ! $this->valid_phone( $phone ) || mb_strlen( $name ) < 3 || mb_strlen( $thikana ) < 5 || mb_strlen( $upazila_city ) < 2 || '' === $district ) wp_send_json_error( array( 'message'=>__( 'Enter a valid name, Bangladeshi phone number and complete address.', 'webzlo-one-page-checkout' ) ) );
		if ( $this->limited( 'order-fp|' . $this->fingerprint(), max( 1, (int) WZL_OPC_Settings::get( 'max_orders_hour', 5 ) ), HOUR_IN_SECONDS ) ) wp_send_json_error( array( 'message'=>__( 'Too many order attempts. Please try again later.', 'webzlo-one-page-checkout' ) ) );
		global $wpdb; $table = $wpdb->prefix . 'wzl_incomplete_orders';
		$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT wc_order_id FROM {$table} WHERE session_key=%s AND wc_order_id>0", $session ) );
		if ( $existing ) { $o=wc_get_order($existing); wp_send_json_success(array('orderId'=>$existing,'redirect'=>$o?$o->get_checkout_order_received_url():wc_get_checkout_url())); }
		$lock = WZL_OPC_Security::acquire_lock( $phone . '|' . $ctx['product_id'], 90 );
		if ( ! $lock ) wp_send_json_error( array( 'message'=>__( 'An order for this phone number is already processing.', 'webzlo-one-page-checkout' ) ) );
		if ( $this->duplicate( $phone, $ctx['product_id'] ) ) { WZL_OPC_Security::release_lock($lock); wp_send_json_error(array('message'=>__('A recent order already exists for this phone number.','webzlo-one-page-checkout'))); }
		$risk = $this->risk( $phone, $name, $address, $this->fingerprint() );
		if ( $risk['score'] >= (int) WZL_OPC_Settings::get( 'block_risk_threshold', 80 ) ) { WZL_OPC_Security::release_lock($lock); wp_send_json_error(array('message'=>__('We could not verify this order. Please contact us.','webzlo-one-page-checkout'))); }
		try {
			$order = wc_create_order(); $order->add_product( $product, $qty );
			$order->set_address(array('first_name'=>$name,'phone'=>$phone,'address_1'=>$thikana,'city'=>$upazila_city,'state'=>$district,'country'=>'BD'),'billing');
			$order->set_address(array('first_name'=>$name,'address_1'=>$thikana,'city'=>$upazila_city,'state'=>$district,'country'=>'BD'),'shipping');
			if ( $ctx['shipping'] > 0 ) { $item=new WC_Order_Item_Shipping(); $item->set_method_title(__('Delivery Charge','webzlo-one-page-checkout')); $item->set_method_id('wzl_opc_delivery'); $item->set_total($ctx['shipping']); $order->add_item($item); }
			$gateways=WC()->payment_gateways()->payment_gateways(); if(isset($gateways['cod'])&&'yes'===$gateways['cod']->enabled)$order->set_payment_method($gateways['cod']); else $order->set_payment_method_title(__('Cash on Delivery','webzlo-one-page-checkout'));
			$order->calculate_totals(); $order->set_created_via('webzlo-one-page-checkout'); $order->update_meta_data('_wzl_opc_session_key',$session); $order->update_meta_data('_wzl_opc_fraud_score',$risk['score']); $order->update_meta_data('_wzl_opc_fraud_reasons',$risk['reasons']); $order->update_meta_data('_wzl_opc_thikana',$thikana); $order->update_meta_data('_wzl_opc_upazila_city',$upazila_city); $order->update_meta_data('_wzl_opc_district',$district);
			$status=$risk['score'] >= (int)WZL_OPC_Settings::get('high_risk_threshold',60)?'on-hold':'processing'; $order->update_status($status,__('Order placed through Webzlo COD Checkout.','webzlo-one-page-checkout')); $order->save();
			$wpdb->update($table,array('status'=>'recovered','wc_order_id'=>$order->get_id(),'updated_at'=>current_time('mysql')),array('session_key'=>$session));
			WZL_OPC_Security::release_lock($lock); wp_send_json_success(array('orderId'=>$order->get_id(),'redirect'=>$order->get_checkout_order_received_url()));
		} catch ( Exception $e ) { WZL_OPC_Security::release_lock($lock); wp_send_json_error(array('message'=>__('The order could not be created.','webzlo-one-page-checkout'))); }
	}
}
