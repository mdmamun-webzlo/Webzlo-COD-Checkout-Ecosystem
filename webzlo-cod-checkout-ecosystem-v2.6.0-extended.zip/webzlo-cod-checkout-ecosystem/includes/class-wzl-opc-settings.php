<?php
defined( 'ABSPATH' ) || exit;

class WZL_OPC_Settings {
	public static function get( $key = null, $default = null ) {
		$settings = wp_parse_args( get_option( 'wzl_opc_settings', array() ), WZL_OPC_Activator::default_settings() );
		return null === $key ? $settings : ( $settings[ $key ] ?? $default );
	}

	public static function sanitize( $input ) {
		$defaults = WZL_OPC_Activator::default_settings();
		$output   = $defaults;
		$numeric  = array( 'duplicate_window', 'max_orders_hour', 'max_incomplete_hour', 'max_quantity', 'max_orders_phone_day', 'abandoned_minutes', 'address_min_length', 'high_risk_threshold', 'block_risk_threshold', 'data_retention_days' );
		foreach ( $numeric as $key ) {
			$output[ $key ] = max( 0, absint( $input[ $key ] ?? $defaults[ $key ] ) );
		}
		$output['blacklist_action']        = in_array( $input['blacklist_action'] ?? '', array( 'block', 'hold' ), true ) ? $input['blacklist_action'] : 'block';
		$output['enable_honeypot']         = ! empty( $input['enable_honeypot'] ) ? 'yes' : 'no';
		$output['enable_rate_limit']       = ! empty( $input['enable_rate_limit'] ) ? 'yes' : 'no';
		$output['enable_phone_reputation'] = ! empty( $input['enable_phone_reputation'] ) ? 'yes' : 'no';
		$output['whatsapp_template']       = sanitize_textarea_field( $input['whatsapp_template'] ?? $defaults['whatsapp_template'] );
		return $output;
	}
}
