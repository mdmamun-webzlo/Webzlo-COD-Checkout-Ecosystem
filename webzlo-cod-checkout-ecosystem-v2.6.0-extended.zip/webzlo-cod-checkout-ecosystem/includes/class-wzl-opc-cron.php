<?php
defined( 'ABSPATH' ) || exit;
class WZL_OPC_Cron {
	public function __construct(){ add_action('wzl_opc_hourly_maintenance',array($this,'run')); self::schedule(); }
	public static function schedule(){ if(!wp_next_scheduled('wzl_opc_hourly_maintenance')) wp_schedule_event(time()+300,'hourly','wzl_opc_hourly_maintenance'); }
	public static function deactivate(){ wp_clear_scheduled_hook('wzl_opc_hourly_maintenance'); }
	public function run(){ global $wpdb; $t=$wpdb->prefix.'wzl_incomplete_orders'; $m=max(5,(int)WZL_OPC_Settings::get('abandoned_minutes',30)); $r=max(30,(int)WZL_OPC_Settings::get('data_retention_days',180)); $wpdb->query($wpdb->prepare("UPDATE {$t} SET status='abandoned' WHERE status='active' AND updated_at<%s",date('Y-m-d H:i:s',current_time('timestamp')-$m*MINUTE_IN_SECONDS))); $wpdb->query($wpdb->prepare("DELETE FROM {$t} WHERE status IN ('ignored','spam') AND updated_at<%s",date('Y-m-d H:i:s',current_time('timestamp')-$r*DAY_IN_SECONDS))); }
}
