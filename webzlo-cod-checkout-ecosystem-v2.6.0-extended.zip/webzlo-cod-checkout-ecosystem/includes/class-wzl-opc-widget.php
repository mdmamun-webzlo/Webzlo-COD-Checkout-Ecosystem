<?php
defined( 'ABSPATH' ) || exit;

class WZL_OPC_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'wzl-one-page-checkout'; }
	public function get_title() { return __( 'One Page Checkout', 'webzlo-one-page-checkout' ); }
	public function get_icon() { return 'eicon-cart'; }
	public function get_categories() { return array( 'webzlo-elements' ); }
	public function get_style_depends() { return array( 'wzl-opc' ); }
	public function get_script_depends() { return array( 'wzl-opc' ); }

	private function product_options() {
		$options  = array( '' => __( 'Select a product', 'webzlo-one-page-checkout' ) );
		$products = wc_get_products(
			array(
				'status'  => 'publish',
				'limit'   => 200,
				'orderby' => 'name',
				'order'   => 'ASC',
				'return'  => 'objects',
			)
		);
		foreach ( $products as $product ) {
			$options[ $product->get_id() ] = $product->get_name();
		}
		return $options;
	}

	private function districts() {
		return array(
			'Bagerhat','Bandarban','Barguna','Barishal','Bhola','Bogura','Brahmanbaria','Chandpur',
			'Chapainawabganj','Chattogram','Chuadanga','Cox’s Bazar','Cumilla','Dhaka','Dinajpur','Faridpur',
			'Feni','Gaibandha','Gazipur','Gopalganj','Habiganj','Jamalpur','Jashore','Jhalokati','Jhenaidah',
			'Joypurhat','Khagrachhari','Khulna','Kishoreganj','Kurigram','Kushtia','Lakshmipur','Lalmonirhat',
			'Madaripur','Magura','Manikganj','Meherpur','Moulvibazar','Munshiganj','Mymensingh','Naogaon',
			'Narail','Narayanganj','Narsingdi','Natore','Netrokona','Nilphamari','Noakhali','Pabna','Panchagarh',
			'Patuakhali','Pirojpur','Rajbari','Rajshahi','Rangamati','Rangpur','Satkhira','Shariatpur','Sherpur',
			'Sirajganj','Sunamganj','Sylhet','Tangail','Thakurgaon'
		);
	}

	protected function register_controls() {
		$this->start_controls_section( 'content_section', array( 'label' => __( 'Checkout Settings', 'webzlo-one-page-checkout' ) ) );

		$this->add_control( 'product_id', array(
			'label' => __( 'Product', 'webzlo-one-page-checkout' ),
			'type' => \Elementor\Controls_Manager::SELECT2,
			'options' => $this->product_options(),
			'default' => '',
		) );

		$this->add_control( 'heading', array(
			'label' => __( 'Checkout Heading', 'webzlo-one-page-checkout' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => __( 'Order Now', 'webzlo-one-page-checkout' ),
		) );

		$this->add_control( 'button_text', array(
			'label' => __( 'Button Text', 'webzlo-one-page-checkout' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => __( 'Place Order', 'webzlo-one-page-checkout' ),
		) );

		$this->add_control( 'shipping_cost', array(
			'label' => __( 'Shipping Cost', 'webzlo-one-page-checkout' ),
			'type' => \Elementor\Controls_Manager::NUMBER,
			'default' => 0,
			'min' => 0,
			'step' => 1,
		) );

		$this->add_control( 'show_short_description', array(
			'label' => __( 'Show Short Description', 'webzlo-one-page-checkout' ),
			'type' => \Elementor\Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default' => 'yes',
		) );
		$this->end_controls_section();

		$this->start_controls_section( 'style_section', array(
			'label' => __( 'Style', 'webzlo-one-page-checkout' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		) );

		$this->add_control( 'primary_color', array(
			'label' => __( 'Primary Color', 'webzlo-one-page-checkout' ),
			'type' => \Elementor\Controls_Manager::COLOR,
			'default' => '#D39A4A',
			'selectors' => array(
				'{{WRAPPER}} .wzl-opc-submit' => 'background-color: {{VALUE}};',
				'{{WRAPPER}} .wzl-opc-qty button' => 'background-color: {{VALUE}};',
				'{{WRAPPER}} .wzl-opc-input:focus' => 'border-color: {{VALUE}} !important;',
			),
		) );

		$this->add_control( 'button_text_color', array(
			'label' => __( 'Button Text Color', 'webzlo-one-page-checkout' ),
			'type' => \Elementor\Controls_Manager::COLOR,
			'default' => '#ffffff',
			'selectors' => array( '{{WRAPPER}} .wzl-opc-submit' => 'color: {{VALUE}};' ),
		) );

		$this->add_responsive_control( 'column_gap', array(
			'label' => __( 'Column Gap', 'webzlo-one-page-checkout' ),
			'type' => \Elementor\Controls_Manager::SLIDER,
			'size_units' => array( 'px' ),
			'range' => array( 'px' => array( 'min' => 0, 'max' => 100 ) ),
			'default' => array( 'size' => 40, 'unit' => 'px' ),
			'selectors' => array( '{{WRAPPER}} .wzl-opc-layout' => 'gap: {{SIZE}}{{UNIT}};' ),
		) );

		$this->add_responsive_control( 'border_radius', array(
			'label' => __( 'Border Radius', 'webzlo-one-page-checkout' ),
			'type' => \Elementor\Controls_Manager::DIMENSIONS,
			'size_units' => array( 'px' ),
			'default' => array( 'top'=>12, 'right'=>12, 'bottom'=>12, 'left'=>12, 'unit'=>'px' ),
			'selectors' => array(
				'{{WRAPPER}} .wzl-opc-panel, {{WRAPPER}} .wzl-opc-input, {{WRAPPER}} .wzl-opc-submit, {{WRAPPER}} .wzl-opc-product-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			),
		) );
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$product_id = absint( $settings['product_id'] );
		$product = $product_id ? wc_get_product( $product_id ) : false;

		if ( ! $product ) {
			echo '<div class="wzl-opc-editor-notice">' . esc_html__( 'Please select a WooCommerce product.', 'webzlo-one-page-checkout' ) . '</div>';
			return;
		}
		if ( ! $product->is_type( 'simple' ) || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			echo '<div class="wzl-opc-editor-notice">' . esc_html__( 'Please select an available simple product.', 'webzlo-one-page-checkout' ) . '</div>';
			return;
		}

		$price = (float) wc_get_price_to_display( $product );
		$shipping_cost = max( 0, (float) $settings['shipping_cost'] );
		$session_key = wp_generate_uuid4();
		$max_quantity = max( 1, min( 100, absint( WZL_OPC_Settings::get( 'max_quantity', 20 ) ) ) );
		$instance_id = 'widget-' . sanitize_key( $this->get_id() );
		$checkout_token = WZL_OPC_Security::create_checkout_token( $product_id, $shipping_cost, $max_quantity, $instance_id );
		?>
		<div class="wzl-opc-wrap"
			data-price="<?php echo esc_attr( $price ); ?>"
			data-shipping="<?php echo esc_attr( $shipping_cost ); ?>"
			data-max-quantity="<?php echo esc_attr( $max_quantity ); ?>">

			<form class="wzl-opc-form" novalidate>
				<div class="wzl-opc-layout">
					<div class="wzl-opc-left-col">
						<div class="wzl-opc-product-image">
							<?php echo wp_kses_post( $product->get_image( 'woocommerce_single', array( 'loading' => 'eager' ) ) ); ?>
						</div>
					</div>

					<div class="wzl-opc-right-col wzl-opc-panel">
						<div class="wzl-opc-product-details">
							<h2 class="wzl-opc-product-title"><?php echo esc_html( $product->get_name() ); ?></h2>
							<div class="wzl-opc-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></div>
							<?php if ( 'yes' === $settings['show_short_description'] && $product->get_short_description() ) : ?>
								<div class="wzl-opc-short-description"><?php echo wp_kses_post( wpautop( $product->get_short_description() ) ); ?></div>
							<?php endif; ?>
						</div>

						<div class="wzl-opc-order-head">
							<h3 class="wzl-opc-heading"><?php echo esc_html( $settings['heading'] ); ?></h3>
							<div class="wzl-opc-qty">
								<button type="button" class="wzl-opc-minus" aria-label="<?php esc_attr_e( 'Decrease quantity', 'webzlo-one-page-checkout' ); ?>">−</button>
								<input type="number" name="quantity" value="1" min="1" max="<?php echo esc_attr( $max_quantity ); ?>" step="1" inputmode="numeric">
								<button type="button" class="wzl-opc-plus" aria-label="<?php esc_attr_e( 'Increase quantity', 'webzlo-one-page-checkout' ); ?>">+</button>
							</div>
						</div>

						<div class="wzl-opc-fields">
							<label><span><?php esc_html_e( 'Customer Name', 'webzlo-one-page-checkout' ); ?> *</span><input class="wzl-opc-input" type="text" name="customer_name" maxlength="100" autocomplete="name" required></label>
							<label><span><?php esc_html_e( 'Phone Number', 'webzlo-one-page-checkout' ); ?> *</span><input class="wzl-opc-input" type="tel" name="phone" maxlength="14" inputmode="tel" autocomplete="tel" placeholder="01XXXXXXXXX" required></label>
							<label><span><?php esc_html_e( 'Thikana', 'webzlo-one-page-checkout' ); ?> *</span><textarea class="wzl-opc-input" name="thikana" maxlength="500" rows="3" autocomplete="street-address" placeholder="House/Road/Village/Area" required></textarea></label>
							<div class="wzl-opc-field-row">
								<label><span><?php esc_html_e( 'Upozila / City', 'webzlo-one-page-checkout' ); ?> *</span><input class="wzl-opc-input" type="text" name="upazila_city" maxlength="100" placeholder="Upozila or City" required></label>
								<label><span><?php esc_html_e( 'Zilla', 'webzlo-one-page-checkout' ); ?> *</span><select class="wzl-opc-input" name="district" required><option value=""><?php esc_html_e( 'Select Zilla', 'webzlo-one-page-checkout' ); ?></option><?php foreach ( $this->districts() as $district ) : ?><option value="<?php echo esc_attr( $district ); ?>"><?php echo esc_html( $district ); ?></option><?php endforeach; ?></select></label>
							</div>
						</div>

						<div class="wzl-opc-summary">
							<div><span><?php esc_html_e( 'Subtotal', 'webzlo-one-page-checkout' ); ?></span><strong class="wzl-opc-subtotal"></strong></div>
							<div><span><?php esc_html_e( 'Shipping', 'webzlo-one-page-checkout' ); ?></span><strong class="wzl-opc-shipping"></strong></div>
							<div class="wzl-opc-total-row"><span><?php esc_html_e( 'Total', 'webzlo-one-page-checkout' ); ?></span><strong class="wzl-opc-total"></strong></div>
						</div>

						<input type="hidden" name="session_key" value="<?php echo esc_attr( $session_key ); ?>">
						<input type="hidden" name="checkout_token" value="<?php echo esc_attr( $checkout_token ); ?>">
						<div class="wzl-opc-trap" aria-hidden="true"><label>Website <input type="text" name="website" value="" tabindex="-1" autocomplete="off"></label></div>
						<div class="wzl-opc-message" aria-live="polite"></div>
						<button type="submit" class="wzl-opc-submit"><span><?php echo esc_html( $settings['button_text'] ); ?></span></button>
					</div>
				</div>
			</form>
		</div>
		<?php
	}
}
