<?php
defined( 'ABSPATH' ) || exit;

class WZL_OPC_Admin {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'actions' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	public function menu() {
		add_menu_page(
			'COD Ecosystem',
			'COD Ecosystem',
			'manage_woocommerce',
			'wzl-opc-dashboard',
			array( $this, 'dashboard' ),
			'dashicons-cart',
			56
		);

		add_submenu_page( 'wzl-opc-dashboard', 'Dashboard', 'Dashboard', 'manage_woocommerce', 'wzl-opc-dashboard', array( $this, 'dashboard' ) );
		add_submenu_page( 'wzl-opc-dashboard', 'Incomplete Orders', 'Incomplete Orders', 'manage_woocommerce', 'wzl-incomplete-orders', array( $this, 'orders' ) );
		add_submenu_page( 'wzl-opc-dashboard', 'Phone Reputation', 'Phone Reputation', 'manage_woocommerce', 'wzl-phone-profiles', array( $this, 'profiles' ) );
		add_submenu_page( 'wzl-opc-dashboard', 'Blacklist', 'Blacklist', 'manage_woocommerce', 'wzl-blacklist', array( $this, 'blacklist' ) );
		add_submenu_page( 'wzl-opc-dashboard', 'Settings', 'Settings', 'manage_woocommerce', 'wzl-opc-settings', array( $this, 'settings' ) );
		add_submenu_page( 'wzl-opc-dashboard', 'Steadfast Courier', 'Steadfast Courier', 'manage_woocommerce', 'wzl-steadfast', array( 'WZL_OPC_Steadfast', 'settings_page' ) );
	}

	public function enqueue_admin_assets( $hook ) {
		if ( 'cod-ecosystem_page_wzl-incomplete-orders' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'wzl-opc-admin',
			WZL_OPC_URL . 'assets/css/admin.css',
			array(),
			WZL_OPC_VERSION
		);

		wp_enqueue_script(
			'wzl-opc-admin',
			WZL_OPC_URL . 'assets/js/admin.js',
			array(),
			WZL_OPC_VERSION,
			true
		);
	}

	public function actions() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		global $wpdb;

		if ( isset( $_POST['wzl_save_settings'] ) ) {
			check_admin_referer( 'wzl_settings' );
			update_option( 'wzl_opc_settings', WZL_OPC_Settings::sanitize( $_POST ) );
			wp_safe_redirect( admin_url( 'admin.php?page=wzl-opc-settings&updated=1' ) );
			exit;
		}

		if ( isset( $_POST['wzl_add_blacklist'] ) ) {
			check_admin_referer( 'wzl_blacklist' );

			$value = sanitize_text_field( wp_unslash( $_POST['value'] ?? '' ) );
			if ( '' !== $value ) {
				$wpdb->replace(
					$wpdb->prefix . 'wzl_opc_blacklist',
					array(
						'type'       => sanitize_key( $_POST['type'] ?? 'phone' ),
						'value'      => $value,
						'reason'     => sanitize_textarea_field( wp_unslash( $_POST['reason'] ?? '' ) ),
						'created_at' => current_time( 'mysql' ),
					)
				);
			}

			wp_safe_redirect( admin_url( 'admin.php?page=wzl-blacklist' ) );
			exit;
		}

		if ( isset( $_GET['wzl_action'], $_GET['id'] ) ) {
			check_admin_referer( 'wzl_action' );

			$id     = absint( $_GET['id'] );
			$action = sanitize_key( $_GET['wzl_action'] );

			if ( 'delete_blacklist' === $action ) {
				$wpdb->delete( $wpdb->prefix . 'wzl_opc_blacklist', array( 'id' => $id ) );
				wp_safe_redirect( admin_url( 'admin.php?page=wzl-blacklist' ) );
				exit;
			}

			if ( in_array( $action, array( 'contacted', 'recovered', 'ignored', 'fraud', 'abandoned' ), true ) ) {
				$wpdb->update(
					$wpdb->prefix . 'wzl_incomplete_orders',
					array(
						'status'     => $action,
						'updated_at' => current_time( 'mysql' ),
					),
					array( 'id' => $id )
				);
			}

			wp_safe_redirect( admin_url( 'admin.php?page=wzl-incomplete-orders' ) );
			exit;
		}
	}

	private function card( $label, $value ) {
		echo '<div style="background:#fff;border:1px solid #ddd;padding:20px;border-radius:8px">';
		echo '<div style="font-size:30px;font-weight:700">' . esc_html( $value ) . '</div>';
		echo '<div>' . esc_html( $label ) . '</div>';
		echo '</div>';
	}

	public function dashboard() {
		global $wpdb;
		$table = $wpdb->prefix . 'wzl_incomplete_orders';

		echo '<div class="wrap"><h1>COD Ecosystem Dashboard</h1>';
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;max-width:900px">';

		foreach ( array( 'Active' => 'active', 'Abandoned' => 'abandoned', 'Recovered' => 'recovered', 'Fraud' => 'fraud' ) as $label => $status ) {
			$count = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status=%s", $status )
			);
			$this->card( $label, $count );
		}

		echo '</div></div>';
	}

	public function orders() {
		global $wpdb;

		$rows = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}wzl_incomplete_orders ORDER BY updated_at DESC LIMIT 300"
		);
		$template = WZL_OPC_Settings::get( 'whatsapp_template', '' );

		echo '<div class="wrap wzl-opc-admin-wrap">';
		echo '<h1>Incomplete Orders</h1>';
		echo '<p>Click <strong>View</strong> to see complete customer and order information.</p>';
		echo '<div class="wzl-opc-table-wrap">';
		echo '<table class="widefat striped wzl-opc-orders-table">';
		echo '<thead><tr>';
		echo '<th>Customer</th><th>Phone</th><th>Address</th><th>Product</th><th>Total</th><th>Risk</th><th>Status</th><th>Updated</th><th>Actions</th>';
		echo '</tr></thead><tbody>';

		if ( ! $rows ) {
			echo '<tr><td colspan="9">No records found.</td></tr>';
		}

		foreach ( $rows as $row ) {
			$product      = wc_get_product( $row->product_id );
			$product_name = $product ? $product->get_name() : '#' . $row->product_id;
			$product_img  = $product ? wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' ) : '';
			$name         = $row->customer_name ?: 'Customer';

			$message = strtr(
				$template,
				array(
					'{name}'    => $name,
					'{phone}'   => $row->phone,
					'{product}' => $product_name,
					'{total}'   => wp_strip_all_tags( wc_price( $row->order_total ) ),
				)
			);

			$wa_phone = '880' . ltrim( $row->phone, '0' );
			$whatsapp = 'https://wa.me/' . rawurlencode( $wa_phone ) . '?text=' . rawurlencode( $message );

			$order_url = '';
			if ( ! empty( $row->wc_order_id ) ) {
				$order = wc_get_order( absint( $row->wc_order_id ) );
				if ( $order ) {
					$order_url = $order->get_edit_order_url();
				}
			}

			$details = array(
				'customer_name'  => $row->customer_name ?: '—',
				'phone'          => $row->phone ?: '—',
				'thikana'        => isset( $row->thikana ) && $row->thikana ? $row->thikana : '—',
				'upazila_city'   => isset( $row->upazila_city ) && $row->upazila_city ? $row->upazila_city : '—',
				'zilla'          => isset( $row->district ) && $row->district ? $row->district : '—',
				'full_address'   => $row->address ?: '—',
				'product_name'   => $product_name,
				'product_image'  => $product_img ?: '',
				'quantity'       => (int) $row->quantity,
				'subtotal'       => wp_strip_all_tags( wc_price( $row->subtotal ) ),
				'shipping'       => wp_strip_all_tags( wc_price( $row->shipping_total ) ),
				'total'          => wp_strip_all_tags( wc_price( $row->order_total ) ),
				'fraud_score'    => (int) $row->fraud_score,
				'fraud_reasons'  => $row->fraud_reasons ?: 'No risk reasons recorded.',
				'status'         => ucfirst( $row->status ),
				'created_at'     => $row->created_at,
				'updated_at'     => $row->updated_at,
				'source_url'     => isset( $row->source_url ) ? esc_url_raw( $row->source_url ) : '',
				'wc_order_id'    => absint( $row->wc_order_id ),
				'wc_order_url'   => $order_url,
			);

			echo '<tr>';
			echo '<td><button type="button" class="button-link wzl-opc-view-customer" data-details="' . esc_attr( wp_json_encode( $details ) ) . '"><strong>' . esc_html( $row->customer_name ?: '—' ) . '</strong></button></td>';
			echo '<td><a href="tel:' . esc_attr( $row->phone ) . '">' . esc_html( $row->phone ) . '</a></td>';
			echo '<td><span class="wzl-opc-address-preview">' . esc_html( $row->address ?: '—' ) . '</span></td>';
			echo '<td>' . esc_html( $product_name ) . ' × ' . esc_html( $row->quantity ) . '</td>';
			echo '<td>' . wp_kses_post( wc_price( $row->order_total ) ) . '</td>';
			echo '<td><strong>' . esc_html( $row->fraud_score ) . '/100</strong></td>';
			echo '<td><span class="wzl-opc-status wzl-opc-status-' . esc_attr( sanitize_html_class( $row->status ) ) . '">' . esc_html( ucfirst( $row->status ) ) . '</span></td>';
			echo '<td>' . esc_html( $row->updated_at ) . '</td>';
			echo '<td class="wzl-opc-actions">';
			echo '<button type="button" class="button button-primary button-small wzl-opc-view-order" data-details="' . esc_attr( wp_json_encode( $details ) ) . '">View</button> ';
			echo '<a class="button button-small" target="_blank" rel="noopener noreferrer" href="' . esc_url( $whatsapp ) . '">WhatsApp</a> ';

			foreach ( array( 'contacted', 'recovered', 'ignored', 'fraud' ) as $action ) {
				$url = wp_nonce_url(
					add_query_arg(
						array(
							'page'       => 'wzl-incomplete-orders',
							'wzl_action' => $action,
							'id'         => $row->id,
						),
						admin_url( 'admin.php' )
					),
					'wzl_action'
				);
				echo '<a class="button button-small" href="' . esc_url( $url ) . '">' . esc_html( ucfirst( $action ) ) . '</a> ';
			}

			echo '</td></tr>';
		}

		echo '</tbody></table></div>';

		$this->render_details_modal();

		echo '</div>';
	}

	private function render_details_modal() {
		?>
		<div id="wzl-opc-details-modal" class="wzl-opc-modal" hidden>
			<div class="wzl-opc-modal-backdrop" data-wzl-close-modal></div>

			<div class="wzl-opc-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="wzl-opc-modal-title">
				<div class="wzl-opc-modal-header">
					<div>
						<h2 id="wzl-opc-modal-title">Incomplete Order Details</h2>
						<p class="wzl-opc-modal-subtitle">Complete customer and checkout information</p>
					</div>

					<button type="button" class="wzl-opc-modal-close" data-wzl-close-modal aria-label="Close popup">&times;</button>
				</div>

				<div class="wzl-opc-modal-body">
					<div class="wzl-opc-modal-product">
						<div class="wzl-opc-modal-product-image">
							<img src="" alt="" data-field-image hidden>
							<div class="wzl-opc-image-placeholder" data-field-image-placeholder>No product image</div>
						</div>

						<div>
							<span class="wzl-opc-detail-label">Product</span>
							<h3 data-field="product_name">—</h3>
							<p>Quantity: <strong data-field="quantity">—</strong></p>
						</div>
					</div>

					<div class="wzl-opc-detail-section">
						<h3>Customer Details</h3>
						<div class="wzl-opc-detail-grid">
							<div><span class="wzl-opc-detail-label">Customer Name</span><strong data-field="customer_name">—</strong></div>
							<div><span class="wzl-opc-detail-label">Phone Number</span><a href="#" data-field-phone data-field="phone">—</a></div>
						</div>
					</div>

					<div class="wzl-opc-detail-section">
						<h3>Delivery Address</h3>
						<div class="wzl-opc-detail-grid">
							<div><span class="wzl-opc-detail-label">Thikana</span><strong data-field="thikana">—</strong></div>
							<div><span class="wzl-opc-detail-label">Upozila / City</span><strong data-field="upazila_city">—</strong></div>
							<div><span class="wzl-opc-detail-label">Zilla</span><strong data-field="zilla">—</strong></div>
							<div class="wzl-opc-detail-full"><span class="wzl-opc-detail-label">Full Address</span><strong data-field="full_address">—</strong></div>
						</div>
					</div>

					<div class="wzl-opc-detail-section">
						<h3>Order Amount</h3>
						<div class="wzl-opc-detail-grid wzl-opc-price-grid">
							<div><span class="wzl-opc-detail-label">Subtotal</span><strong data-field="subtotal">—</strong></div>
							<div><span class="wzl-opc-detail-label">Delivery Charge</span><strong data-field="shipping">—</strong></div>
							<div><span class="wzl-opc-detail-label">Total</span><strong data-field="total">—</strong></div>
						</div>
					</div>

					<div class="wzl-opc-detail-section">
						<h3>Risk &amp; Activity</h3>
						<div class="wzl-opc-detail-grid">
							<div><span class="wzl-opc-detail-label">Status</span><strong data-field="status">—</strong></div>
							<div><span class="wzl-opc-detail-label">Fraud Score</span><strong><span data-field="fraud_score">0</span>/100</strong></div>
							<div><span class="wzl-opc-detail-label">Created</span><strong data-field="created_at">—</strong></div>
							<div><span class="wzl-opc-detail-label">Last Activity</span><strong data-field="updated_at">—</strong></div>
							<div class="wzl-opc-detail-full"><span class="wzl-opc-detail-label">Risk Reasons</span><strong data-field="fraud_reasons">—</strong></div>
						</div>
					</div>
				</div>

				<div class="wzl-opc-modal-footer">
					<a class="button" href="#" target="_blank" rel="noopener noreferrer" data-field-source hidden>Open Checkout Page</a>
					<a class="button button-primary" href="#" data-field-order hidden>Open WooCommerce Order</a>
					<button type="button" class="button" data-wzl-close-modal>Close</button>
				</div>
			</div>
		</div>
		<?php
	}

	public function profiles() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}wzl_opc_phone_profiles ORDER BY updated_at DESC LIMIT 300" );

		echo '<div class="wrap"><h1>Phone Reputation</h1>';
		echo '<table class="widefat striped"><thead><tr><th>Phone</th><th>Orders</th><th>Success</th><th>Cancelled</th><th>Failed</th><th>Incomplete</th><th>Spent</th><th>Status</th></tr></thead><tbody>';

		if ( ! $rows ) {
			echo '<tr><td colspan="8">No profiles found.</td></tr>';
		}

		foreach ( $rows as $row ) {
			echo '<tr>';
			echo '<td>' . esc_html( $row->phone ) . '</td>';
			echo '<td>' . esc_html( $row->total_orders ) . '</td>';
			echo '<td>' . esc_html( $row->successful_orders ) . '</td>';
			echo '<td>' . esc_html( $row->cancelled_orders ) . '</td>';
			echo '<td>' . esc_html( $row->failed_orders ) . '</td>';
			echo '<td>' . esc_html( $row->incomplete_checkouts ) . '</td>';
			echo '<td>' . wp_kses_post( wc_price( $row->total_spent ) ) . '</td>';
			echo '<td><strong>' . esc_html( ucfirst( $row->trust_status ) ) . '</strong></td>';
			echo '</tr>';
		}

		echo '</tbody></table></div>';
	}

	public function blacklist() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}wzl_opc_blacklist ORDER BY created_at DESC" );

		echo '<div class="wrap"><h1>Blacklist</h1>';
		echo '<form method="post" style="background:#fff;padding:20px;max-width:700px;margin-bottom:20px">';

		wp_nonce_field( 'wzl_blacklist' );

		echo '<p><select name="type"><option value="phone">Phone</option><option value="fingerprint">Device fingerprint</option></select></p>';
		echo '<p><input class="regular-text" name="value" required placeholder="Value"></p>';
		echo '<p><textarea class="large-text" name="reason" placeholder="Reason"></textarea></p>';
		echo '<button class="button button-primary" name="wzl_add_blacklist" value="1">Add to Blacklist</button>';
		echo '</form>';

		echo '<table class="widefat striped"><thead><tr><th>Type</th><th>Value</th><th>Reason</th><th>Created</th><th>Action</th></tr></thead><tbody>';

		if ( ! $rows ) {
			echo '<tr><td colspan="5">Blacklist is empty.</td></tr>';
		}

		foreach ( $rows as $row ) {
			$url = wp_nonce_url(
				add_query_arg(
					array(
						'page'       => 'wzl-blacklist',
						'wzl_action' => 'delete_blacklist',
						'id'         => $row->id,
					),
					admin_url( 'admin.php' )
				),
				'wzl_action'
			);

			echo '<tr>';
			echo '<td>' . esc_html( $row->type ) . '</td>';
			echo '<td>' . esc_html( $row->value ) . '</td>';
			echo '<td>' . esc_html( $row->reason ) . '</td>';
			echo '<td>' . esc_html( $row->created_at ) . '</td>';
			echo '<td><a class="button button-small" href="' . esc_url( $url ) . '">Delete</a></td>';
			echo '</tr>';
		}

		echo '</tbody></table></div>';
	}

	public function settings() {
		$settings = WZL_OPC_Settings::get();

		echo '<div class="wrap"><h1>COD Ecosystem Settings</h1>';

		if ( isset( $_GET['updated'] ) ) {
			echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
		}

		echo '<form method="post">';
		wp_nonce_field( 'wzl_settings' );

		$fields = array(
			'duplicate_window'     => 'Duplicate window (minutes)',
			'max_orders_hour'      => 'Max orders per device/hour',
			'max_orders_phone_day' => 'Max orders per phone/day',
			'abandoned_minutes'    => 'Mark abandoned after (minutes)',
			'address_min_length'   => 'Minimum address length',
			'high_risk_threshold'  => 'Hold risk score',
			'block_risk_threshold' => 'Block risk score',
			'data_retention_days'  => 'Data retention (days)',
		);

		echo '<table class="form-table">';

		foreach ( $fields as $key => $label ) {
			echo '<tr><th>' . esc_html( $label ) . '</th><td><input type="number" name="' . esc_attr( $key ) . '" value="' . esc_attr( $settings[ $key ] ) . '" min="0"></td></tr>';
		}

		echo '<tr><th>Blacklist action</th><td><select name="blacklist_action">';
		echo '<option value="block" ' . selected( $settings['blacklist_action'], 'block', false ) . '>Block</option>';
		echo '<option value="hold" ' . selected( $settings['blacklist_action'], 'hold', false ) . '>Put on hold</option>';
		echo '</select></td></tr>';

		foreach ( array( 'enable_honeypot' => 'Honeypot', 'enable_rate_limit' => 'Rate limiting', 'enable_phone_reputation' => 'Phone reputation' ) as $key => $label ) {
			echo '<tr><th>' . esc_html( $label ) . '</th><td><label><input type="checkbox" name="' . esc_attr( $key ) . '" value="1" ' . checked( $settings[ $key ], 'yes', false ) . '> Enable</label></td></tr>';
		}

		echo '<tr><th>WhatsApp template</th><td><textarea class="large-text" rows="5" name="whatsapp_template">' . esc_textarea( $settings['whatsapp_template'] ) . '</textarea><p>{name}, {phone}, {product}, {total}</p></td></tr>';
		echo '</table>';
		echo '<button class="button button-primary" name="wzl_save_settings" value="1">Save Settings</button>';
		echo '</form></div>';
	}
}
