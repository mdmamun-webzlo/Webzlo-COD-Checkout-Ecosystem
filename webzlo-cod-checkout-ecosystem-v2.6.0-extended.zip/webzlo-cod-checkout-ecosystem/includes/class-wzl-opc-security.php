<?php
defined( 'ABSPATH' ) || exit;

class WZL_OPC_Security {
	public static function create_checkout_token( $product_id, $shipping, $max_quantity, $instance_id ) {
		$payload = array(
			'product_id'   => absint( $product_id ),
			'shipping'     => wc_format_decimal( max( 0, (float) $shipping ), 2 ),
			'max_quantity' => max( 1, absint( $max_quantity ) ),
			'instance_id'  => sanitize_key( $instance_id ),
			'issued_at'    => time(),
		);
		$json      = wp_json_encode( $payload );
		$encoded   = self::base64url_encode( $json );
		$signature = hash_hmac( 'sha256', $encoded, wp_salt( 'auth' ) );
		return $encoded . '.' . $signature;
	}

	public static function verify_checkout_token( $token ) {
		if ( ! is_string( $token ) || strlen( $token ) > 1500 || 1 !== substr_count( $token, '.' ) ) {
			return new WP_Error( 'invalid_checkout_token' );
		}
		list( $encoded, $signature ) = explode( '.', $token, 2 );
		$expected = hash_hmac( 'sha256', $encoded, wp_salt( 'auth' ) );
		if ( ! hash_equals( $expected, $signature ) ) {
			return new WP_Error( 'invalid_checkout_signature' );
		}
		$json = self::base64url_decode( $encoded );
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) || empty( $data['product_id'] ) || empty( $data['issued_at'] ) ) {
			return new WP_Error( 'invalid_checkout_payload' );
		}
		if ( abs( time() - absint( $data['issued_at'] ) ) > 12 * HOUR_IN_SECONDS ) {
			return new WP_Error( 'expired_checkout_token' );
		}
		$data['product_id']   = absint( $data['product_id'] );
		$data['shipping']     = max( 0, (float) $data['shipping'] );
		$data['max_quantity'] = max( 1, min( 100, absint( $data['max_quantity'] ) ) );
		return $data;
	}

	public static function valid_session_key( $session ) {
		return is_string( $session ) && (bool) preg_match( '/^[a-f0-9-]{36}$/i', $session );
	}

	public static function acquire_lock( $key, $ttl = 60 ) {
		$option = 'wzl_opc_lock_' . hash( 'sha256', $key );
		$now    = time();
		$expiry = (int) get_option( $option, 0 );
		if ( $expiry && $expiry < $now ) {
			delete_option( $option );
		}
		return add_option( $option, $now + absint( $ttl ), '', false ) ? $option : false;
	}

	public static function release_lock( $option ) {
		if ( $option ) {
			delete_option( $option );
		}
	}

	private static function base64url_encode( $value ) {
		return rtrim( strtr( base64_encode( $value ), '+/', '-_' ), '=' );
	}

	private static function base64url_decode( $value ) {
		$padding = strlen( $value ) % 4;
		if ( $padding ) {
			$value .= str_repeat( '=', 4 - $padding );
		}
		return base64_decode( strtr( $value, '-_', '+/' ), true );
	}
}
