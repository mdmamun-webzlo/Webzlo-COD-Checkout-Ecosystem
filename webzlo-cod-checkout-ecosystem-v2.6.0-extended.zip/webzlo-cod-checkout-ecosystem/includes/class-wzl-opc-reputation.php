<?php
defined( 'ABSPATH' ) || exit;

class WZL_OPC_Reputation {
	public static function is_blacklisted( $phone, $fingerprint = '' ) {
		global $wpdb;
		$table = $wpdb->prefix . 'wzl_opc_blacklist';
		$values = array( array( 'phone', $phone ) );
		if ( $fingerprint ) {
			$values[] = array( 'fingerprint', $fingerprint );
		}
		foreach ( $values as $item ) {
			$found = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE type = %s AND value = %s LIMIT 1", $item[0], $item[1] ) );
			if ( $found ) return true;
		}
		return false;
	}

	public static function profile( $phone ) {
		global $wpdb;
		$table = $wpdb->prefix . 'wzl_opc_phone_profiles';
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE phone = %s", $phone ) );
	}

	public static function sync_phone( $phone ) {
		if ( ! $phone || 'yes' !== WZL_OPC_Settings::get( 'enable_phone_reputation', 'yes' ) ) return;
		global $wpdb;
		$table = $wpdb->prefix . 'wzl_opc_phone_profiles';
		$orders = wc_get_orders( array( 'limit' => -1, 'billing_phone' => $phone, 'return' => 'objects' ) );
		$total = $success = $cancelled = $failed = 0;
		$spent = 0.0;
		$last = null;
		foreach ( $orders as $order ) {
			$total++;
			$status = $order->get_status();
			if ( in_array( $status, array( 'processing', 'completed' ), true ) ) { $success++; $spent += (float) $order->get_total(); }
			if ( 'cancelled' === $status ) $cancelled++;
			if ( 'failed' === $status || 'refunded' === $status ) $failed++;
			$date = $order->get_date_created();
			if ( $date && ( ! $last || $date->getTimestamp() > strtotime( $last ) ) ) $last = $date->date( 'Y-m-d H:i:s' );
		}
		$sessions = $wpdb->prefix . 'wzl_incomplete_orders';
		$incomplete = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$sessions} WHERE phone = %s AND status IN ('active','abandoned','contacted')", $phone ) );
		$trust = 'new';
		if ( $success >= 3 && 0 === $failed ) $trust = 'trusted';
		elseif ( $cancelled + $failed >= 3 ) $trust = 'high-risk';
		$data = array( 'phone'=>$phone, 'total_orders'=>$total, 'successful_orders'=>$success, 'cancelled_orders'=>$cancelled, 'failed_orders'=>$failed, 'incomplete_checkouts'=>$incomplete, 'total_spent'=>$spent, 'trust_status'=>$trust, 'last_order_at'=>$last, 'updated_at'=>current_time('mysql') );
		$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE phone = %s", $phone ) );
		if ( $exists ) $wpdb->update( $table, $data, array( 'id'=>(int)$exists ) ); else $wpdb->insert( $table, $data );
	}
}
