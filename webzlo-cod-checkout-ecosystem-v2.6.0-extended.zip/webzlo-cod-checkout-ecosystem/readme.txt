=== Webzlo COD Checkout Ecosystem ===
Contributors: webzlo
Tags: woocommerce, elementor, checkout, cod, abandoned order, fraud prevention
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.6.0
License: GPLv2 or later

Secure Elementor-supported WooCommerce one-page COD checkout for Bangladesh.

== Security in 2.1.0 ==

* Server-signed checkout configuration.
* Product ID, delivery charge, quantity limit and issue time verified server-side.
* Only published, purchasable simple products accepted.
* Quantity, stock, sold-individually and input-length validation.
* Rate limits for abandoned checkout creation by device and phone.
* Atomic phone-and-product duplicate lock.
* No public order number disclosure on duplicate detection.
* No full phone reputation recalculation during autosave.
* Uses REMOTE_ADDR rather than trusting spoofable proxy headers.
* Nonces, capability checks, sanitization, escaping and prepared SQL retained.

== Installation ==

Upload the ZIP through Plugins > Add New, activate it, then add One Page Checkout from Elementor > Webzlo Elements.


= 2.2.0 =
* Added responsive 50/50 product and checkout layout.
* Product image displays in the left column.
* Product title, price, short description and checkout form display in the right column.
* Replaced the single address field with Thikana, Upozila/City and Zilla.
* Added a server-validated list of all 64 Bangladesh districts.
* Stores address parts in incomplete orders and WooCommerce order metadata.
* Maps Thikana, Upozila/City and Zilla into WooCommerce billing and shipping addresses.


= 2.5.0 =
* Full single-package build.
* Incomplete-order View Details popup.
* Steadfast Courier manual and automatic parcel creation.
* Courier status checking and order meta data.
* Duplicate-load and WooCommerce order-screen compatibility protection.


= 2.5.1 =
* Fixed fatal error on the Steadfast Courier settings page.
* Added complete secure Steadfast API settings form.
* Added masked credential preservation.

= 2.5.2 =
* Fixed Steadfast Courier API hostname.
* Updated API base URL to the official https://portal.packzy.com/api/v1 endpoint.
* Create-order and delivery-status requests now use the official Packzy host.


= 2.5.3 =
* Shows exact Steadfast HTTP/API errors instead of a generic failure.
* Normalizes Bangladesh phone numbers to 11 digits.
* Validates recipient name, phone, address and COD amount before submission.
* Adds item description, total lot and delivery type to parcel payload.
* Stores the last payload and API error details in order metadata for diagnostics.


= 2.6.0 =
* Added Steadfast balance checking.
* Added bulk parcel creation for up to 500 WooCommerce orders.
* Added return request creation and listing.
* Added payments and single payment lookup.
* Added police station lookup.
* Added return request button to WooCommerce orders.
* Added Steadfast settings tabs and API response viewer.
